/**
 * WebKMT Backend Server
 * Express.js server with Firebase integration
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const path = require('path');
require('dotenv').config();

// Import Firebase Admin
const admin = require('firebase-admin');

// Import routes
const authRoutes = require('./routes/auth');
const dataRoutes = require('./routes/data');
const analyticsRoutes = require('./routes/analytics');
const contactRoutes = require('./routes/contact');
const miniAppsRoutes = require('../api/mini-apps/routes');
const { handleGeminiRequest } = require('./routes/gemini-proxy');

// Import middleware
const { authenticate } = require('./middleware/authenticate');
const { errorHandler } = require('./middleware/errorHandler');
const { logger } = require('./middleware/logger');

const app = express();
// Force port 8083 to override system environment variable
const PORT = 8083;

// Initialize Firebase Admin
try {
  let serviceAccount = null;

  // Try to load from environment variable first
  if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
    serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY);
    console.log('🔥 Loading Firebase Admin from environment variable');
  } else {
    // Try to load from file
    try {
      const fs = require('fs');
      const path = require('path');
      const serviceAccountPath = path.join(__dirname, 'config', 'firebase-service-account.json');
      if (fs.existsSync(serviceAccountPath)) {
        serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
        console.log('🔥 Loading Firebase Admin from service account file');
      }
    } catch (fileError) {
      console.log('📋 Firebase service account file not found');
    }
  }

  if (serviceAccount) {
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
      databaseURL: process.env.FIREBASE_DATABASE_URL || 'https://webkmt-40b44-default-rtdb.firebaseio.com'
    });
    console.log('✅ Firebase Admin initialized successfully');
  } else {
    console.log('⚠️  Firebase service account not found. Server will run in limited mode.');
    console.log('📋 To enable full functionality:');
    console.log('   1. Download service account key from Firebase Console');
    console.log('   2. Save as server/config/firebase-service-account.json');
    console.log('   3. Or set FIREBASE_SERVICE_ACCOUNT_KEY environment variable');
  }
} catch (error) {
  console.error('❌ Firebase Admin initialization failed:', error.message);
  console.log('🔧 Server will continue without Firebase Admin functionality');
}

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      scriptSrc: [
        "'self'",
        "'unsafe-inline'",
        "https://www.gstatic.com",
        "https://www.googletagmanager.com",
        "https://googletagmanager.com",
        "https://www.google.com",
        "https://www.gstatic.com/recaptcha/",
        "https://www.recaptcha.net",
        "https://apis.google.com"
      ],
      scriptSrcAttr: ["'unsafe-inline'"], // Allow inline event handlers temporarily
      connectSrc: [
        "'self'",
        "https://*.googleapis.com",
        "https://*.firebaseio.com",
        "https://*.firebase.com",
        "https://*.firebaseapp.com",
        "https://identitytoolkit.googleapis.com",
        "https://securetoken.googleapis.com",
        "https://www.googleapis.com",
        "https://firebase.googleapis.com",
        "https://firebaseinstallations.googleapis.com",
        "https://firestore.googleapis.com",
        "https://www.gstatic.com",
        "https://api.apify.com",
        "https://colormind.io",
        "https://www.google-analytics.com",
        "https://analytics.google.com",
        "https://region1.google-analytics.com",
        "https://stats.g.doubleclick.net",
        "https://googletagmanager.com",
        "https://www.googletagmanager.com",
        "https://accounts.google.com",
        "https://content-firebaseappcheck.googleapis.com",
        "https://www.google.com",
        "https://www.recaptcha.net"
      ],
      frameSrc: [
        "'self'",
        "https://webkmt-40b44.firebaseapp.com",
        "https://accounts.google.com",
        "https://www.google.com",
        "https://www.recaptcha.net"
      ],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      formAction: ["'self'"]
    }
  },
  crossOriginEmbedderPolicy: false, // Allow iframe embedding for mini-apps
  crossOriginResourcePolicy: { policy: "cross-origin" }
}));

// Rate limiting with different limits for different endpoints
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.RATE_LIMIT_MAX_REQUESTS || 100,
  message: {
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: Math.ceil((process.env.RATE_LIMIT_WINDOW_MS || 900000) / 1000)
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limiting for health checks and static assets
    return req.path.startsWith('/api/health') || 
           req.path.startsWith('/css/') || 
           req.path.startsWith('/js/') || 
           req.path.startsWith('/assets/');
  }
});

// Stricter rate limiting for sensitive endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5, // Strict limit for auth endpoints
  message: { error: 'Too many authentication attempts, please try again later.' },
  skipSuccessfulRequests: true
});

app.use('/api', generalLimiter);
app.use('/api/auth', authLimiter);

// Enhanced CORS configuration
const getAllowedOrigins = () => {
  if (process.env.ALLOWED_ORIGINS) {
    return process.env.ALLOWED_ORIGINS.split(',').map(origin => origin.trim());
  }
  
  const productionOrigins = ['https://webkmt.com', 'https://www.webkmt.com', 'https://linkbio.webkmt.com'];
  const developmentOrigins = ['http://localhost:8083', 'http://localhost:6000', 'http://127.0.0.1:5500'];
  
  // Always allow localhost origins for development, even in production environment
  return process.env.NODE_ENV === 'production' 
    ? [...productionOrigins, ...developmentOrigins]
    : developmentOrigins;
};

app.use(cors({
  origin: (origin, callback) => {
    const allowedOrigins = getAllowedOrigins();
    
    // Allow requests with no origin (mobile apps, Postman, etc.)
    if (!origin && process.env.NODE_ENV !== 'production') {
      return callback(null, true);
    }
    
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`Origin ${origin} not allowed by CORS`));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['X-Total-Count', 'X-Page-Count']
}));

// Body parsing middleware with security enhancements
app.use(compression());

// Input validation and sanitization middleware (only for POST/PUT/PATCH)
const validateAndSanitizeInput = (req, res, next) => {
  // Skip sanitization for GET/HEAD/OPTIONS requests
  if (!['POST', 'PUT', 'PATCH'].includes(req.method)) {
    return next();
  }

  if (req.body && typeof req.body === 'object') {
    // Basic input sanitization
    const sanitizeString = (str) => {
      if (typeof str !== 'string') return str;
      
      // Remove potentially dangerous characters but preserve functionality
      return str
        .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
        .replace(/javascript:/gi, '') // Remove javascript: protocols
        .replace(/on\w+\s*=/gi, '') // Remove event handlers
        .trim()
        .substring(0, 10000); // Limit string length
    };

    const sanitizeObject = (obj) => {
      for (const key in obj) {
        if (obj.hasOwnProperty(key)) {
          if (typeof obj[key] === 'string') {
            obj[key] = sanitizeString(obj[key]);
          } else if (typeof obj[key] === 'object' && obj[key] !== null) {
            sanitizeObject(obj[key]);
          }
        }
      }
    };

    sanitizeObject(req.body);
  }
  next();
};

app.use(express.json({ 
  limit: '5mb', // Reduced from 10mb for security
  strict: true,
  type: 'application/json'
}));
app.use(express.urlencoded({ 
  extended: false, // Changed to false for security
  limit: '5mb',
  parameterLimit: 100 // Limit number of parameters
}));

app.use(validateAndSanitizeInput);

// Custom middleware
app.use(logger);

// Static files
app.use(express.static(path.join(__dirname, '../'), {
  maxAge: '1d',
  etag: true,
  lastModified: true
}));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/data', authenticate, dataRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/contact', contactRoutes);
app.use('/api/mini-apps', miniAppsRoutes);

// Secure AI Proxy Routes
app.post('/api/gemini-chat', generalLimiter, handleGeminiRequest);

// Bio-link handler for webkmt.com/{username}
app.get('/:username', async (req, res) => {
  const username = req.params.username;
  const hostname = req.get('host');
  
  // Skip if this looks like a static file or known route
  const skipRoutes = ['api', 'mini-apps', 'js', 'css', 'assets', 'images', 'fonts', 'sw.js', 'manifest.json', 'favicon.ico'];
  if (username.includes('.') || skipRoutes.some(route => username.startsWith(route))) {
    return res.sendFile(path.join(__dirname, '..', 'index.html'));
  }
  
  try {
    // Check if this username exists in Firebase
    if (admin.apps.length > 0) {
      const db = admin.firestore();
      const profileDoc = await db.collection('public_profiles').doc(username).get();
      
      if (profileDoc.exists) {
        // Serve the public profile page for this user
        return res.sendFile(path.join(__dirname, '..', 'mini-apps', 'kmtlink-public-profile.html'));
      }
    }
    
    // If username doesn't exist, serve main site
    res.sendFile(path.join(__dirname, '..', 'index.html'));
  } catch (error) {
    console.error('Error checking bio-link profile:', error);
    // Fallback to main site
    res.sendFile(path.join(__dirname, '..', 'index.html'));
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: process.env.npm_package_version || '1.0.0',
    environment: process.env.NODE_ENV || 'development'
  });
});

// Serve React app for all non-API routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../index.html'));
});

// Error handling middleware
app.use(errorHandler);

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`📂 Serving static files from: ${path.join(__dirname, '../')}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  process.exit(0);
});

module.exports = app;