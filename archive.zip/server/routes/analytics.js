/**
 * Analytics Routes
 * Handles performance tracking and user analytics
 */

const express = require('express');
const admin = require('firebase-admin');
const router = express.Router();

// Firestore instance (will be initialized when available)
let db = null;

// Initialize Firebase services when admin is available
const initializeFirebaseServices = () => {
  try {
    db = admin.firestore();
    console.log('✅ Firestore initialized in analytics route');
  } catch (error) {
    console.warn('⚠️  Firestore not available in analytics route');
  }
};

// Initialize services if admin app exists
setTimeout(initializeFirebaseServices, 100);

// Track page view
router.post('/pageview', async (req, res) => {
  try {
    const { page, referrer, userAgent, timestamp } = req.body;

    if (!page) {
      return res.status(400).json({
        success: false,
        error: 'Page is required'
      });
    }

    const analyticsData = {
      type: 'pageview',
      page,
      referrer: referrer || '',
      userAgent: userAgent || '',
      timestamp: timestamp ? new Date(timestamp) : new Date().toISOString(),
      ip: req.ip,
      createdAt: new Date().toISOString()
    };

    if (db) {
      try {
        await db.collection('analytics').add({
          ...analyticsData,
          timestamp: timestamp ? new Date(timestamp) : admin.firestore.FieldValue.serverTimestamp(),
          createdAt: admin.firestore.FieldValue.serverTimestamp()
        });
        console.log(`📊 Pageview tracked: ${page}`);
      } catch (error) {
        console.error('Failed to save pageview to Firestore:', error);
        console.log('📊 Pageview tracked (local):', analyticsData);
      }
    } else {
      console.log('📊 Pageview tracked (local):', analyticsData);
    }

    res.json({
      success: true,
      message: 'Pageview tracked successfully'
    });

  } catch (error) {
    console.error('Pageview tracking error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to track pageview'
    });
  }
});

// Track Core Web Vitals
router.post('/web-vitals', async (req, res) => {
  try {
    const { metrics } = req.body;

    if (!metrics || typeof metrics !== 'object') {
      return res.status(400).json({
        success: false,
        error: 'Metrics object is required'
      });
    }

    const webVitalsData = {
      type: 'web-vitals',
      metrics: {
        LCP: metrics.LCP || null,
        FID: metrics.FID || null,
        CLS: metrics.CLS || null,
        FCP: metrics.FCP || null,
        TTFB: metrics.TTFB || null,
        INP: metrics.INP || null
      },
      url: req.headers.referer || '',
      userAgent: req.headers['user-agent'] || '',
      timestamp: new Date().toISOString(),
      ip: req.ip
    };

    if (db) {
      try {
        await db.collection('analytics').add({
          ...webVitalsData,
          timestamp: admin.firestore.FieldValue.serverTimestamp()
        });
        console.log('📊 Web Vitals tracked');
      } catch (error) {
        console.error('Failed to save Web Vitals to Firestore:', error);
        console.log('📊 Web Vitals tracked (local):', webVitalsData);
      }
    } else {
      console.log('📊 Web Vitals tracked (local):', webVitalsData);
    }

    res.json({
      success: true,
      message: 'Web Vitals tracked successfully'
    });

  } catch (error) {
    console.error('Web Vitals tracking error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to track Web Vitals'
    });
  }
});

// Track user events
router.post('/event', async (req, res) => {
  try {
    const { eventName, eventData, category } = req.body;

    if (!eventName) {
      return res.status(400).json({
        success: false,
        error: 'Event name is required'
      });
    }

    const eventAnalytics = {
      type: 'event',
      eventName,
      eventData: eventData || {},
      category: category || 'general',
      url: req.headers.referer || '',
      userAgent: req.headers['user-agent'] || '',
      timestamp: new Date().toISOString(),
      ip: req.ip
    };

    if (db) {
      try {
        await db.collection('analytics').add({
          ...eventAnalytics,
          timestamp: admin.firestore.FieldValue.serverTimestamp()
        });
        console.log(`📊 Event tracked: ${eventName}`);
      } catch (error) {
        console.error('Failed to save event to Firestore:', error);
        console.log('📊 Event tracked (local):', eventAnalytics);
      }
    } else {
      console.log('📊 Event tracked (local):', eventAnalytics);
    }

    res.json({
      success: true,
      message: 'Event tracked successfully'
    });

  } catch (error) {
    console.error('Event tracking error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to track event'
    });
  }
});

// Track errors
router.post('/error', async (req, res) => {
  try {
    const { message, stack, filename, lineno, colno } = req.body;

    if (!message) {
      return res.status(400).json({
        success: false,
        error: 'Error message is required'
      });
    }

    const errorData = {
      type: 'error',
      message,
      stack: stack || '',
      filename: filename || '',
      lineno: lineno || 0,
      colno: colno || 0,
      url: req.headers.referer || '',
      userAgent: req.headers['user-agent'] || '',
      timestamp: new Date().toISOString(),
      ip: req.ip
    };

    if (db) {
      try {
        await db.collection('analytics').add({
          ...errorData,
          timestamp: admin.firestore.FieldValue.serverTimestamp()
        });
        console.log(`📊 Error tracked: ${message}`);
      } catch (error) {
        console.error('Failed to save error to Firestore:', error);
        console.log('📊 Error tracked (local):', errorData);
      }
    } else {
      console.log('📊 Error tracked (local):', errorData);
    }

    res.json({
      success: true,
      message: 'Error tracked successfully'
    });

  } catch (error) {
    console.error('Error tracking error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to track error'
    });
  }
});

// Get analytics data (public endpoint with rate limiting)
router.get('/stats', async (req, res) => {
  try {
    const { period = '7d', type } = req.query;

    if (!db) {
      return res.json({
        success: true,
        data: {
          totalEvents: 0,
          pageviews: 0,
          webVitals: {},
          errors: 0,
          events: 0,
          topPages: [],
          topEvents: []
        }
      });
    }

    // Calculate date range
    const now = new Date();
    const startDate = new Date();
    
    switch (period) {
      case '1d':
        startDate.setDate(now.getDate() - 1);
        break;
      case '7d':
        startDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        startDate.setDate(now.getDate() - 30);
        break;
      default:
        startDate.setDate(now.getDate() - 7);
    }

    let query = db.collection('analytics')
      .where('timestamp', '>=', startDate)
      .orderBy('timestamp', 'desc');

    if (type) {
      query = query.where('type', '==', type);
    }

    const snapshot = await query.limit(1000).get();

    if (snapshot.empty) {
      return res.json({
        success: true,
        data: {
          totalEvents: 0,
          pageviews: 0,
          webVitals: {},
          errors: 0,
          events: 0
        }
      });
    }

    const analytics = snapshot.docs.map(doc => doc.data());

    // Aggregate data
    const stats = {
      totalEvents: analytics.length,
      pageviews: analytics.filter(a => a.type === 'pageview').length,
      webVitals: aggregateWebVitals(analytics.filter(a => a.type === 'web-vitals')),
      errors: analytics.filter(a => a.type === 'error').length,
      events: analytics.filter(a => a.type === 'event').length,
      topPages: getTopPages(analytics.filter(a => a.type === 'pageview')),
      topEvents: getTopEvents(analytics.filter(a => a.type === 'event'))
    };

    res.json({
      success: true,
      data: stats
    });

  } catch (error) {
    console.error('Analytics fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch analytics'
    });
  }
});

// Helper function to aggregate Web Vitals
function aggregateWebVitals(webVitalsData) {
  if (webVitalsData.length === 0) return {};

  const metrics = {
    LCP: [],
    FID: [],
    CLS: [],
    FCP: [],
    TTFB: [],
    INP: []
  };

  webVitalsData.forEach(data => {
    Object.keys(metrics).forEach(metric => {
      if (data.metrics && data.metrics[metric] !== null) {
        metrics[metric].push(data.metrics[metric]);
      }
    });
  });

  const result = {};
  Object.keys(metrics).forEach(metric => {
    if (metrics[metric].length > 0) {
      const values = metrics[metric];
      result[metric] = {
        avg: values.reduce((a, b) => a + b, 0) / values.length,
        p75: percentile(values, 0.75),
        p95: percentile(values, 0.95),
        count: values.length
      };
    }
  });

  return result;
}

// Helper function to get top pages
function getTopPages(pageviews) {
  const pageCount = {};
  pageviews.forEach(pv => {
    pageCount[pv.page] = (pageCount[pv.page] || 0) + 1;
  });

  return Object.entries(pageCount)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 10)
    .map(([page, count]) => ({ page, count }));
}

// Helper function to get top events
function getTopEvents(events) {
  const eventCount = {};
  events.forEach(evt => {
    const key = `${evt.category}:${evt.eventName}`;
    eventCount[key] = (eventCount[key] || 0) + 1;
  });

  return Object.entries(eventCount)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 10)
    .map(([event, count]) => ({ event, count }));
}

// Helper function to calculate percentile
function percentile(values, p) {
  const sorted = values.slice().sort((a, b) => a - b);
  const index = Math.ceil(sorted.length * p) - 1;
  return sorted[index];
}

// Track performance metrics
router.post('/performance', async (req, res) => {
  try {
    const { metrics, session, timestamp } = req.body;

    if (!metrics || !Array.isArray(metrics)) {
      return res.status(400).json({
        success: false,
        error: 'Metrics array is required'
      });
    }

    // Process each metric in the batch
    const performanceData = metrics.map(metric => ({
      type: 'performance',
      metricName: metric.name,
      metricData: metric.data,
      url: metric.url || req.headers.referer || '',
      userAgent: metric.userAgent || req.headers['user-agent'] || '',
      connection: metric.connection || null,
      viewport: metric.viewport || null,
      session: session || null,
      timestamp: timestamp ? new Date(timestamp) : new Date().toISOString(),
      ip: req.ip
    }));

    if (db) {
      try {
        // Batch write for efficiency
        const batch = db.batch();

        performanceData.forEach(data => {
          const docRef = db.collection('analytics').doc();
          batch.set(docRef, {
            ...data,
            timestamp: timestamp ? new Date(timestamp) : admin.firestore.FieldValue.serverTimestamp()
          });
        });

        await batch.commit();
        console.log(`📊 Performance metrics tracked: ${metrics.length} metrics`);
      } catch (error) {
        console.error('Failed to save performance metrics to Firestore:', error);
        console.log('📊 Performance metrics tracked (local):', performanceData.length, 'metrics');
      }
    } else {
      console.log('📊 Performance metrics tracked (local):', performanceData.length, 'metrics');
    }

    res.json({
      success: true,
      message: `Performance metrics tracked successfully (${metrics.length} metrics)`
    });

  } catch (error) {
    console.error('Performance tracking error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to track performance metrics'
    });
  }
});

module.exports = router;