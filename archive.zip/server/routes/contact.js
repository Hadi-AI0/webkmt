/**
 * Contact Routes
 * Handles contact form submissions and inquiries
 */

const express = require('express');
const admin = require('firebase-admin');
const router = express.Router();

// Firestore instance (will be initialized when available)
let db = null;

// Initialize Firebase services when admin is available
const initializeFirebaseServices = () => {
  try {
    db = admin.firestore();
    console.log('✅ Firestore initialized in contact route');
  } catch (error) {
    console.warn('⚠️  Firestore not available in contact route');
  }
};

// Initialize services if admin app exists
setTimeout(initializeFirebaseServices, 100);

// Contact form submission
router.post('/submit', async (req, res) => {
  try {
    const { name, email, subject, message, phone, company, service } = req.body;

    // Validation
    if (!name || !email || !message) {
      return res.status(400).json({
        success: false,
        error: 'Name, email, and message are required'
      });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email format'
      });
    }

    // Prepare contact data
    const contactData = {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      subject: subject ? subject.trim() : 'General Inquiry',
      message: message.trim(),
      phone: phone ? phone.trim() : '',
      company: company ? company.trim() : '',
      service: service || 'general',
      status: 'new',
      source: 'website',
      ip: req.ip,
      userAgent: req.headers['user-agent'] || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    let docId = 'temp-' + Date.now();

    // Save to Firestore if available, otherwise log locally
    if (db) {
      try {
        const docRef = await db.collection('contacts').add({
          ...contactData,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        docId = docRef.id;
        console.log(`📧 Contact form saved to Firestore: ${docId} from ${email}`);
      } catch (error) {
        console.error('Failed to save to Firestore:', error);
        console.log('📧 Contact form submission (local):', contactData);
      }
    } else {
      console.log('📧 Contact form submission received:', contactData);
    }

    res.json({
      success: true,
      message: 'Thank you for your message! We will get back to you soon.',
      data: {
        id: docId,
        status: 'submitted'
      }
    });

  } catch (error) {
    console.error('Contact form submission error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to submit contact form. Please try again later.'
    });
  }
});

// Newsletter subscription
router.post('/newsletter', async (req, res) => {
  try {
    const { email, preferences } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        error: 'Email is required'
      });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email format'
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    if (!db) {
      console.log(`📧 Newsletter subscription (local): ${normalizedEmail}`);
      return res.json({
        success: true,
        message: 'Successfully subscribed to our newsletter!',
        data: {
          id: 'temp-' + Date.now(),
          email: normalizedEmail
        }
      });
    }

    // Check if email already exists
    const existingSubscriber = await db.collection('newsletter')
      .where('email', '==', normalizedEmail)
      .get();

    if (!existingSubscriber.empty) {
      return res.status(409).json({
        success: false,
        error: 'Email is already subscribed to our newsletter'
      });
    }

    // Save subscription
    const subscriptionData = {
      email: normalizedEmail,
      preferences: preferences || {
        marketing: true,
        updates: true,
        news: true
      },
      status: 'active',
      source: 'website',
      ip: req.ip,
      userAgent: req.headers['user-agent'] || '',
      subscribedAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    const docRef = await db.collection('newsletter').add(subscriptionData);

    console.log(`New newsletter subscription: ${docRef.id} - ${normalizedEmail}`);

    res.json({
      success: true,
      message: 'Successfully subscribed to our newsletter!',
      data: {
        id: docRef.id,
        email: normalizedEmail
      }
    });

  } catch (error) {
    console.error('Newsletter subscription error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to subscribe to newsletter. Please try again later.'
    });
  }
});

// Unsubscribe from newsletter
router.post('/newsletter/unsubscribe', async (req, res) => {
  try {
    const { email, token } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        error: 'Email is required'
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    if (!db) {
      console.log(`Newsletter unsubscribe (local): ${normalizedEmail}`);
      return res.json({
        success: true,
        message: 'Successfully unsubscribed from our newsletter'
      });
    }

    // Find subscription
    const subscription = await db.collection('newsletter')
      .where('email', '==', normalizedEmail)
      .get();

    if (subscription.empty) {
      return res.status(404).json({
        success: false,
        error: 'Email not found in our newsletter list'
      });
    }

    // Update subscription status
    const docRef = subscription.docs[0].ref;
    await docRef.update({
      status: 'unsubscribed',
      unsubscribedAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });

    console.log(`Newsletter unsubscribe: ${normalizedEmail}`);

    res.json({
      success: true,
      message: 'Successfully unsubscribed from our newsletter'
    });

  } catch (error) {
    console.error('Newsletter unsubscribe error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to unsubscribe. Please try again later.'
    });
  }
});

// Get contact form submissions (protected endpoint)
router.get('/submissions', async (req, res) => {
  try {
    const { status, limit = 50, offset = 0 } = req.query;

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    let query = db.collection('contacts').orderBy('createdAt', 'desc');

    if (status) {
      query = query.where('status', '==', status);
    }

    query = query.limit(parseInt(limit)).offset(parseInt(offset));

    const snapshot = await query.get();

    if (snapshot.empty) {
      return res.json({
        success: true,
        data: []
      });
    }

    const submissions = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      // Remove sensitive data
      ip: undefined,
      userAgent: undefined
    }));

    res.json({
      success: true,
      data: submissions
    });

  } catch (error) {
    console.error('Contact submissions fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch contact submissions'
    });
  }
});

// Update contact submission status (protected endpoint)
router.put('/submissions/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    if (!status) {
      return res.status(400).json({
        success: false,
        error: 'Status is required'
      });
    }

    const validStatuses = ['new', 'in-progress', 'responded', 'closed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status'
      });
    }

    const updateData = {
      status,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    if (notes !== undefined) {
      updateData.notes = notes;
    }

    await db.collection('contacts').doc(id).update(updateData);

    res.json({
      success: true,
      message: 'Contact submission updated successfully'
    });

  } catch (error) {
    console.error('Contact submission update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update contact submission'
    });
  }
});

// Quote request (for project inquiries)
router.post('/quote', async (req, res) => {
  try {
    const { 
      name, 
      email, 
      phone, 
      company, 
      projectType, 
      budget, 
      timeline, 
      description,
      features 
    } = req.body;

    // Validation
    if (!name || !email || !projectType || !description) {
      return res.status(400).json({
        success: false,
        error: 'Name, email, project type, and description are required'
      });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid email format'
      });
    }

    const quoteData = {
      name: name.trim(),
      email: email.toLowerCase().trim(),
      phone: phone ? phone.trim() : '',
      company: company ? company.trim() : '',
      projectType,
      budget: budget || 'not-specified',
      timeline: timeline || 'flexible',
      description: description.trim(),
      features: features || [],
      status: 'new',
      type: 'quote-request',
      source: 'website',
      ip: req.ip,
      userAgent: req.headers['user-agent'] || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    let docId = 'temp-' + Date.now();

    if (db) {
      try {
        const docRef = await db.collection('quotes').add({
          ...quoteData,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          updatedAt: admin.firestore.FieldValue.serverTimestamp()
        });
        docId = docRef.id;
        console.log(`New quote request: ${docRef.id} from ${email}`);
      } catch (error) {
        console.error('Failed to save quote to Firestore:', error);
        console.log('📧 Quote request (local):', quoteData);
      }
    } else {
      console.log('📧 Quote request (local):', quoteData);
    }

    res.json({
      success: true,
      message: 'Thank you for your quote request! We will review your project and get back to you within 24 hours.',
      data: {
        id: docId,
        status: 'submitted'
      }
    });

  } catch (error) {
    console.error('Quote request error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to submit quote request. Please try again later.'
    });
  }
});

module.exports = router;