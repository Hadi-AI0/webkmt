/**
 * Authentication Routes
 * Handles Firebase Auth operations
 */

const express = require('express');
const admin = require('firebase-admin');
const router = express.Router();

// Firebase Auth instance (will be initialized when available)
let auth = null;
let db = null;

// Helper function to check if user is admin
const isAdminUser = (email) => {
  return email && email.toLowerCase() === 'info@webkmt.com';
};

// Helper function to verify admin permissions
const verifyAdminPermissions = async (decodedToken) => {
  // Check custom claims first
  if (decodedToken.admin === true && decodedToken.role === 'admin') {
    return true;
  }

  // Fallback to email check
  if (isAdminUser(decodedToken.email)) {
    return true;
  }

  // Check Firestore profile as final fallback
  try {
    const userDoc = await db.collection('users').doc(decodedToken.uid).get();
    if (userDoc.exists) {
      const userData = userDoc.data();
      return userData.role === 'admin' && isAdminUser(userData.email);
    }
  } catch (error) {
    console.error('Error checking user profile:', error);
  }

  return false;
};

// Initialize Firebase services when admin is available
const initializeFirebaseServices = () => {
  try {
    auth = admin.auth();
    db = admin.firestore();
    console.log('✅ Firebase services initialized in auth route');
  } catch (error) {
    console.warn('⚠️  Firebase services not available in auth route');
  }
};

// Initialize services if admin app exists
setTimeout(initializeFirebaseServices, 100);

// Register user
router.post('/register', async (req, res) => {
  try {
    const { email, password, displayName } = req.body;

    if (!email || !password) {
      return res.status(400).json({ 
        success: false, 
        error: 'Email and password are required' 
      });
    }

    if (!auth) {
      return res.status(503).json({
        success: false,
        error: 'Authentication service not available'
      });
    }

    // Create user in Firebase Auth
    const userRecord = await auth.createUser({
      email,
      password,
      displayName
    });

    // Determine user role - info@webkmt.com gets admin role
    const userRole = isAdminUser(email) ? 'admin' : 'user';

    // Create user profile in Firestore
    const userProfileData = {
      uid: userRecord.uid,
      email: userRecord.email,
      displayName: displayName || '',
      photoURL: '',
      role: userRole,
      plan: userRole === 'admin' ? 'premium' : 'free',
      emailVerified: false,
      isAnonymous: false,
      preferences: {
        theme: 'light',
        language: 'en',
        notifications: true
      },
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      lastSignIn: admin.firestore.FieldValue.serverTimestamp()
    };

    await db.collection('users').doc(userRecord.uid).set(userProfileData);

    // Set custom claims for admin user
    if (userRole === 'admin') {
      await auth.setCustomUserClaims(userRecord.uid, {
        admin: true,
        role: 'admin',
        email: email.toLowerCase()
      });
      console.log('✅ Admin user created with custom claims for:', email);
    } else {
      // Set custom claims for regular users too (for consistency)
      await auth.setCustomUserClaims(userRecord.uid, {
        admin: false,
        role: 'user',
        email: email.toLowerCase()
      });
      console.log('✅ User created with custom claims for:', email);
    }

    // Generate custom token
    const customToken = await auth.createCustomToken(userRecord.uid);

    res.json({
      success: true,
      data: {
        token: customToken,
        user: {
          uid: userRecord.uid,
          email: userRecord.email,
          displayName: userRecord.displayName
        }
      }
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
});

// Note: Authentication now handled client-side via Firebase Auth SDK with App Check
// Server only handles registration and token verification

// Verify token
router.post('/verify', async (req, res) => {
  try {
    const { token } = req.body;

    if (!token) {
      return res.status(400).json({
        success: false,
        error: 'Token is required'
      });
    }

    if (!auth) {
      return res.status(503).json({
        success: false,
        error: 'Authentication service not available'
      });
    }

    // Verify the ID token
    const decodedToken = await auth.verifyIdToken(token);
    const uid = decodedToken.uid;

    // Get user profile from Firestore
    const userDoc = await db.collection('users').doc(uid).get();
    
    if (!userDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'User profile not found'
      });
    }

    const userData = userDoc.data();

    res.json({
      success: true,
      data: {
        user: userData
      }
    });

  } catch (error) {
    console.error('Token verification error:', error);
    res.status(401).json({
      success: false,
      error: 'Invalid token'
    });
  }
});

// Update user profile
router.put('/profile', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Authorization token required'
      });
    }

    if (!auth) {
      return res.status(503).json({
        success: false,
        error: 'Authentication service not available'
      });
    }

    const decodedToken = await auth.verifyIdToken(token);
    const uid = decodedToken.uid;

    const { displayName, preferences, photoURL } = req.body;

    const updateData = {
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    if (displayName !== undefined) updateData.displayName = displayName;
    if (preferences !== undefined) updateData.preferences = preferences;
    if (photoURL !== undefined) updateData.photoURL = photoURL;

    await db.collection('users').doc(uid).update(updateData);

    // Update Firebase Auth profile if needed
    const authUpdateData = {};
    if (displayName !== undefined) authUpdateData.displayName = displayName;
    if (photoURL !== undefined) authUpdateData.photoURL = photoURL;

    if (Object.keys(authUpdateData).length > 0) {
      await auth.updateUser(uid, authUpdateData);
    }

    res.json({
      success: true,
      message: 'Profile updated successfully'
    });

  } catch (error) {
    console.error('Profile update error:', error);
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
});

// Password reset
router.post('/reset-password', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        error: 'Email is required'
      });
    }

    if (!auth) {
      return res.status(503).json({
        success: false,
        error: 'Authentication service not available'
      });
    }

    // Generate password reset link
    const link = await auth.generatePasswordResetLink(email);

    // In production, you would send this via email
    // For now, we'll return it in the response
    res.json({
      success: true,
      message: 'Password reset link generated',
      link: process.env.NODE_ENV === 'development' ? link : undefined
    });

  } catch (error) {
    console.error('Password reset error:', error);
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
});

// Delete user
router.delete('/user', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Authorization token required'
      });
    }

    if (!auth) {
      return res.status(503).json({
        success: false,
        error: 'Authentication service not available'
      });
    }

    const decodedToken = await auth.verifyIdToken(token);
    const uid = decodedToken.uid;

    // Delete user data from Firestore
    await db.collection('users').doc(uid).delete();
    
    // Delete user from Firebase Auth
    await auth.deleteUser(uid);

    res.json({
      success: true,
      message: 'User deleted successfully'
    });

  } catch (error) {
    console.error('User deletion error:', error);
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
});

// Set custom claims (for social login users)
router.post('/set-claims', async (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
      return res.status(401).json({
        success: false,
        error: 'Authorization token required'
      });
    }

    if (!auth) {
      return res.status(503).json({
        success: false,
        error: 'Authentication service not available'
      });
    }

    const decodedToken = await auth.verifyIdToken(token);
    const { uid, role } = req.body;

    // Verify the token UID matches the requested UID
    if (decodedToken.uid !== uid) {
      return res.status(403).json({
        success: false,
        error: 'Token UID mismatch'
      });
    }

    // Verify the user is admin if setting admin role
    if (role === 'admin' && !isAdminUser(decodedToken.email)) {
      return res.status(403).json({
        success: false,
        error: 'Admin role can only be set for authorized email'
      });
    }

    // Set custom claims
    const customClaims = {
      admin: role === 'admin',
      role: role,
      email: decodedToken.email.toLowerCase()
    };

    await auth.setCustomUserClaims(uid, customClaims);

    res.json({
      success: true,
      message: 'Custom claims set successfully'
    });

  } catch (error) {
    console.error('Set claims error:', error);
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;