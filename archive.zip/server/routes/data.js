/**
 * Data Routes
 * Handles Firebase Firestore operations
 */

const express = require('express');
const admin = require('firebase-admin');
const router = express.Router();

// Firestore instance (will be initialized when available)
let db = null;

// Initialize Firebase services when admin is available
const initializeFirebaseServices = () => {
  try {
    db = admin.firestore();
    console.log('✅ Firestore initialized in data route');
  } catch (error) {
    console.warn('⚠️  Firestore not available in data route');
  }
};

// Initialize services if admin app exists
setTimeout(initializeFirebaseServices, 100);

// Save user data
router.post('/save', async (req, res) => {
  try {
    const { collection, data } = req.body;
    const userId = req.user?.uid;

    if (!collection || !data) {
      return res.status(400).json({
        success: false,
        error: 'Collection and data are required'
      });
    }

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    // Add metadata
    const docData = {
      ...data,
      userId,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    const docRef = await db.collection(collection).add(docData);

    res.json({
      success: true,
      data: {
        id: docRef.id,
        ...docData
      }
    });

  } catch (error) {
    console.error('Data save error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to save data'
    });
  }
});

// Get user data
router.get('/:collection', async (req, res) => {
  try {
    const { collection } = req.params;
    const userId = req.user?.uid;
    const { limit = 10, offset = 0 } = req.query;

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    let query = db.collection(collection)
      .where('userId', '==', userId)
      .orderBy('createdAt', 'desc');

    if (limit) {
      query = query.limit(parseInt(limit));
    }

    if (offset) {
      query = query.offset(parseInt(offset));
    }

    const snapshot = await query.get();
    
    if (snapshot.empty) {
      return res.json({
        success: true,
        data: []
      });
    }

    const data = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));

    res.json({
      success: true,
      data
    });

  } catch (error) {
    console.error('Data fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch data'
    });
  }
});

// Update user data
router.put('/:collection/:id', async (req, res) => {
  try {
    const { collection, id } = req.params;
    const { data } = req.body;
    const userId = req.user?.uid;

    if (!data) {
      return res.status(400).json({
        success: false,
        error: 'Data is required'
      });
    }

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    // Verify ownership
    const docRef = db.collection(collection).doc(id);
    const doc = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({
        success: false,
        error: 'Document not found'
      });
    }

    if (doc.data().userId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized to update this document'
      });
    }

    // Update document
    const updateData = {
      ...data,
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };

    await docRef.update(updateData);

    res.json({
      success: true,
      message: 'Data updated successfully'
    });

  } catch (error) {
    console.error('Data update error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to update data'
    });
  }
});

// Delete user data
router.delete('/:collection/:id', async (req, res) => {
  try {
    const { collection, id } = req.params;
    const userId = req.user?.uid;

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    // Verify ownership
    const docRef = db.collection(collection).doc(id);
    const doc = await docRef.get();

    if (!doc.exists) {
      return res.status(404).json({
        success: false,
        error: 'Document not found'
      });
    }

    if (doc.data().userId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized to delete this document'
      });
    }

    // Delete document
    await docRef.delete();

    res.json({
      success: true,
      message: 'Data deleted successfully'
    });

  } catch (error) {
    console.error('Data delete error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to delete data'
    });
  }
});

// Batch operations
router.post('/batch', async (req, res) => {
  try {
    const { operations } = req.body;
    const userId = req.user?.uid;

    if (!operations || !Array.isArray(operations)) {
      return res.status(400).json({
        success: false,
        error: 'Operations array is required'
      });
    }

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    const batch = db.batch();
    const results = [];

    for (const operation of operations) {
      const { type, collection, id, data } = operation;

      switch (type) {
        case 'create':
          const docRef = db.collection(collection).doc();
          batch.set(docRef, {
            ...data,
            userId,
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
          results.push({ id: docRef.id, type: 'create' });
          break;

        case 'update':
          const updateRef = db.collection(collection).doc(id);
          batch.update(updateRef, {
            ...data,
            updatedAt: admin.firestore.FieldValue.serverTimestamp()
          });
          results.push({ id, type: 'update' });
          break;

        case 'delete':
          const deleteRef = db.collection(collection).doc(id);
          batch.delete(deleteRef);
          results.push({ id, type: 'delete' });
          break;

        default:
          throw new Error(`Invalid operation type: ${type}`);
      }
    }

    await batch.commit();

    res.json({
      success: true,
      data: results
    });

  } catch (error) {
    console.error('Batch operation error:', error);
    res.status(500).json({
      success: false,
      error: 'Batch operation failed'
    });
  }
});

// Get document by ID
router.get('/:collection/:id', async (req, res) => {
  try {
    const { collection, id } = req.params;
    const userId = req.user?.uid;

    if (!db) {
      return res.status(503).json({
        success: false,
        error: 'Database not available'
      });
    }

    const doc = await db.collection(collection).doc(id).get();

    if (!doc.exists) {
      return res.status(404).json({
        success: false,
        error: 'Document not found'
      });
    }

    const data = doc.data();

    if (data.userId !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Unauthorized to access this document'
      });
    }

    res.json({
      success: true,
      data: {
        id: doc.id,
        ...data
      }
    });

  } catch (error) {
    console.error('Document fetch error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to fetch document'
    });
  }
});

module.exports = router;