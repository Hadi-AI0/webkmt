/**
 * Authentication Middleware
 * Verifies Firebase ID tokens for protected routes
 */

const admin = require('firebase-admin');

const authenticate = async (req, res, next) => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        error: 'Authorization token required. Please provide a Bearer token.'
      });
    }

    const idToken = authHeader.replace('Bearer ', '');

    if (!idToken) {
      return res.status(401).json({
        success: false,
        error: 'Invalid authorization format. Token is required.'
      });
    }

    // Verify the ID token
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    
    if (!decodedToken) {
      return res.status(401).json({
        success: false,
        error: 'Invalid token. Authentication failed.'
      });
    }

    // Get user data from Firestore
    const userDoc = await admin.firestore()
      .collection('users')
      .doc(decodedToken.uid)
      .get();

    if (!userDoc.exists) {
      return res.status(404).json({
        success: false,
        error: 'User profile not found. Please contact support.'
      });
    }

    const userData = userDoc.data();

    // Check if user account is active
    if (userData.status === 'disabled' || userData.status === 'suspended') {
      return res.status(403).json({
        success: false,
        error: 'Account is disabled. Please contact support.'
      });
    }

    // Attach user info to request
    req.user = {
      uid: decodedToken.uid,
      email: decodedToken.email,
      emailVerified: decodedToken.email_verified,
      displayName: userData.displayName || '',
      photoURL: userData.photoURL || '',
      plan: userData.plan || 'free',
      preferences: userData.preferences || {},
      roles: userData.roles || [],
      createdAt: userData.createdAt,
      lastLoginAt: decodedToken.auth_time ? new Date(decodedToken.auth_time * 1000) : null
    };

    // Batch update last seen timestamp (every 5 minutes max)
    const now = Date.now();
    const lastUpdate = global.userLastSeenUpdates = global.userLastSeenUpdates || {};

    if (!lastUpdate[decodedToken.uid] || (now - lastUpdate[decodedToken.uid]) > 300000) { // 5 minutes
      lastUpdate[decodedToken.uid] = now;

      // Update asynchronously to not block the request
      admin.firestore()
        .collection('users')
        .doc(decodedToken.uid)
        .update({
          lastSeenAt: admin.firestore.FieldValue.serverTimestamp()
        })
        .catch(updateError => {
          console.warn('Failed to update lastSeenAt:', updateError);
        });
    }

    next();

  } catch (error) {
    console.error('Authentication error:', error);

    // Handle specific Firebase Auth errors
    if (error.code === 'auth/id-token-expired') {
      return res.status(401).json({
        success: false,
        error: 'Token has expired. Please sign in again.',
        code: 'TOKEN_EXPIRED'
      });
    }

    if (error.code === 'auth/id-token-revoked') {
      return res.status(401).json({
        success: false,
        error: 'Token has been revoked. Please sign in again.',
        code: 'TOKEN_REVOKED'
      });
    }

    if (error.code === 'auth/invalid-id-token') {
      return res.status(401).json({
        success: false,
        error: 'Invalid token format. Please sign in again.',
        code: 'INVALID_TOKEN'
      });
    }

    if (error.code === 'auth/user-disabled') {
      return res.status(403).json({
        success: false,
        error: 'User account has been disabled.',
        code: 'ACCOUNT_DISABLED'
      });
    }

    // Generic error
    return res.status(401).json({
      success: false,
      error: 'Authentication failed. Please sign in again.',
      code: 'AUTH_ERROR'
    });
  }
};

// Optional authentication middleware (doesn't fail if no token)
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      // No token provided, continue without authentication
      req.user = null;
      return next();
    }

    const idToken = authHeader.replace('Bearer ', '');

    if (!idToken) {
      req.user = null;
      return next();
    }

    // Verify the ID token
    const decodedToken = await admin.auth().verifyIdToken(idToken);
    
    if (decodedToken) {
      // Get user data from Firestore
      const userDoc = await admin.firestore()
        .collection('users')
        .doc(decodedToken.uid)
        .get();

      if (userDoc.exists) {
        const userData = userDoc.data();
        
        req.user = {
          uid: decodedToken.uid,
          email: decodedToken.email,
          emailVerified: decodedToken.email_verified,
          displayName: userData.displayName || '',
          photoURL: userData.photoURL || '',
          plan: userData.plan || 'free',
          preferences: userData.preferences || {},
          roles: userData.roles || []
        };
      } else {
        req.user = null;
      }
    } else {
      req.user = null;
    }

    next();

  } catch (error) {
    // On error, continue without authentication
    console.warn('Optional authentication failed:', error);
    req.user = null;
    next();
  }
};

// Role-based authorization middleware
const requireRole = (requiredRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required'
      });
    }

    const userRoles = req.user.roles || [];
    const hasRole = requiredRoles.some(role => userRoles.includes(role));

    if (!hasRole) {
      return res.status(403).json({
        success: false,
        error: 'Insufficient permissions'
      });
    }

    next();
  };
};

// Plan-based authorization middleware
const requirePlan = (requiredPlans) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication required'
      });
    }

    const userPlan = req.user.plan || 'free';
    
    if (!requiredPlans.includes(userPlan)) {
      return res.status(403).json({
        success: false,
        error: 'Plan upgrade required',
        required: requiredPlans,
        current: userPlan
      });
    }

    next();
  };
};

module.exports = {
  authenticate,
  optionalAuth,
  requireRole,
  requirePlan
};