/**
 * Error Handler Middleware
 * Centralized error handling for Express.js application
 */

const admin = require('firebase-admin');

// Custom error class
class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
    this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

// Handle different types of errors
const handleCastErrorDB = (err) => {
  const message = `Invalid ${err.path}: ${err.value}`;
  return new AppError(message, 400);
};

const handleDuplicateFieldsDB = (err) => {
  const value = err.errmsg.match(/(["'])(\\?.)*?\1/)[0];
  const message = `Duplicate field value: ${value}. Please use another value!`;
  return new AppError(message, 400);
};

const handleValidationErrorDB = (err) => {
  const errors = Object.values(err.errors).map(el => el.message);
  const message = `Invalid input data. ${errors.join('. ')}`;
  return new AppError(message, 400);
};


// Send error in development
const sendErrorDev = (err, req, res) => {
  // Log error for debugging
  console.error('ERROR 💥', {
    message: err.message || 'Unknown error',
    statusCode: err.statusCode || 500,
    stack: err.stack || 'No stack trace available'
  });

  res.status(err.statusCode || 500).json({
    success: false,
    error: err.message || 'Internal server error',
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
};

// Send error in production
const sendErrorProd = async (err, req, res) => {
  // Log error to Firebase for monitoring (only if Firebase is available)
  try {
    if (admin.apps.length > 0) {
      await admin.firestore().collection('error_logs').add({
        message: err.message,
        stack: err.stack,
        statusCode: err.statusCode,
        url: req.originalUrl,
        method: req.method,
        userAgent: req.headers['user-agent'],
        ip: req.ip,
        userId: req.user?.uid || null,
        timestamp: admin.firestore.FieldValue.serverTimestamp()
      });
    }
  } catch (logError) {
    console.error('Failed to log error to Firebase:', logError);
  }

  // Operational, trusted error: send message to client
  if (err.isOperational) {
    res.status(err.statusCode).json({
      success: false,
      error: err.message
    });
  } else {
    // Programming or other unknown error: don't leak error details
    console.error('ERROR 💥', {
      message: err.message || 'Unknown error',
      statusCode: err.statusCode || 500,
      stack: err.stack
    });

    res.status(500).json({
      success: false,
      error: 'Something went wrong on our end. Please try again later.'
    });
  }
};

// Main error handling middleware
const errorHandler = (err, req, res, next) => {
  err.statusCode = err.statusCode || 500;
  err.status = err.status || 'error';

  if (process.env.NODE_ENV === 'development') {
    sendErrorDev(err, req, res);
  } else {
    let error = { ...err };
    error.message = err.message;

    // Handle specific error types
    if (error.name === 'CastError') error = handleCastErrorDB(error);
    if (error.code === 11000) error = handleDuplicateFieldsDB(error);
    if (error.name === 'ValidationError') error = handleValidationErrorDB(error);

    // Handle Firebase errors
    if (error.code && error.code.startsWith('auth/')) {
      switch (error.code) {
        case 'auth/invalid-id-token':
          error = new AppError('Invalid authentication token', 401);
          break;
        case 'auth/id-token-expired':
          error = new AppError('Authentication token has expired', 401);
          break;
        case 'auth/id-token-revoked':
          error = new AppError('Authentication token has been revoked', 401);
          break;
        case 'auth/user-disabled':
          error = new AppError('User account has been disabled', 403);
          break;
        case 'auth/user-not-found':
          error = new AppError('User not found', 404);
          break;
        case 'auth/invalid-email':
          error = new AppError('Invalid email address', 400);
          break;
        case 'auth/weak-password':
          error = new AppError('Password is too weak', 400);
          break;
        case 'auth/email-already-in-use':
          error = new AppError('Email is already in use', 409);
          break;
        default:
          error = new AppError('Authentication error', 401);
      }
    }

    // Handle Firestore errors
    if (error.code && error.code.includes('firestore/')) {
      switch (error.code) {
        case 'firestore/permission-denied':
          error = new AppError('Permission denied', 403);
          break;
        case 'firestore/not-found':
          error = new AppError('Document not found', 404);
          break;
        case 'firestore/already-exists':
          error = new AppError('Document already exists', 409);
          break;
        case 'firestore/invalid-argument':
          error = new AppError('Invalid request data', 400);
          break;
        case 'firestore/resource-exhausted':
          error = new AppError('Rate limit exceeded', 429);
          break;
        default:
          error = new AppError('Database error', 500);
      }
    }

    sendErrorProd(error, req, res);
  }
};

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.log('UNCAUGHT EXCEPTION! 💥 Shutting down...');
  console.log(err.name, err.message);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  console.log('UNHANDLED REJECTION! 💥 Shutting down...');
  console.log(err.name, err.message);
  process.exit(1);
});

// 404 handler for non-existent routes
const notFound = (req, res, next) => {
  const err = new AppError(`Can't find ${req.originalUrl} on this server!`, 404);
  next(err);
};

// Async error wrapper to catch errors in async functions
const catchAsync = (fn) => {
  return (req, res, next) => {
    fn(req, res, next).catch(next);
  };
};

// Rate limit error handler
const rateLimitHandler = (req, res) => {
  res.status(429).json({
    success: false,
    error: 'Too many requests from this IP, please try again later.',
    retryAfter: req.rateLimit.resetTime
  });
};

module.exports = {
  errorHandler,
  notFound,
  catchAsync,
  rateLimitHandler,
  AppError
};