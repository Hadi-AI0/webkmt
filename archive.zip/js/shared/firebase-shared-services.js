/**
 * Firebase Shared Services for Mini-Apps
 * Provides unified Firebase-based services for auth, database, storage, and analytics
 */

import { 
  auth, 
  db, 
  storage, 
  functions, 
  analytics 
} from '../firebase-config.js';

import { 
  ref, 
  uploadBytes, 
  getDownloadURL, 
  deleteObject,
  getMetadata,
  updateMetadata
} from 'firebase/storage';

import { 
  httpsCallable 
} from 'firebase/functions';

import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  collection, 
  query, 
  where, 
  orderBy, 
  limit, 
  getDocs,
  serverTimestamp 
} from 'firebase/firestore';

import { logEvent } from 'firebase/analytics';

class FirebaseSharedServices {
  constructor() {
    this.eventListeners = new Map();
    this.uploadProgress = new Map();
    
    this.init();
  }

  init() {
    this.setupEventHandlers();
    
    // Wait for auth to be ready
    if (window.authManager) {
      window.authManager.waitForAuth().then(() => {
        console.log('🔥 Firebase Shared Services initialized');
      });
    }
  }

  // ===============================================
  // Authentication Service (Proxy to Auth Manager)
  // ===============================================

  async signIn(credentials) {
    return window.authManager?.signInWithEmail(credentials.email, credentials.password, credentials.rememberMe);
  }

  async signUp(userData) {
    return window.authManager?.signUpWithEmail(userData.email, userData.password, userData.displayName);
  }

  async signInWithGoogle() {
    return window.authManager?.signInWithGoogle();
  }

  async signInWithGitHub() {
    return window.authManager?.signInWithGitHub();
  }

  async signOut() {
    return window.authManager?.signOut();
  }

  isSignedIn() {
    return window.authManager?.isLoggedIn() || false;
  }

  getCurrentUser() {
    return window.authManager?.getUser();
  }

  async requireAuth() {
    if (!this.isSignedIn()) {
      throw new Error('Authentication required');
    }
    return true;
  }

  // ===============================================
  // Data Service (Proxy to Data Sync Manager)
  // ===============================================

  async saveData(collection, data, options = {}) {
    await this.requireAuth();
    
    const appId = options.app || 'main';
    const dataKey = options.id || `${collection}_${this.generateId()}`;
    
    try {
      const result = await window.dataSyncManager?.set(appId, dataKey, {
        collection,
        data,
        metadata: {
          userId: this.getCurrentUser()?.uid,
          timestamp: new Date().toISOString(),
          ...options.metadata
        }
      });

      this.emit('data:saved', { collection, data: result.data, appId, dataKey });
      this.trackEvent('data_saved', { collection, app_id: appId });
      
      return { success: true, data: result.data, id: dataKey };
    } catch (error) {
      console.error('Save data error:', error);
      return { success: false, error: error.message };
    }
  }

  async loadData(collection, options = {}) {
    await this.requireAuth();
    
    const appId = options.app || 'main';
    
    try {
      let result;
      
      if (options.id) {
        // Load specific document
        result = await window.dataSyncManager?.get(appId, options.id);
        if (result?.success && result.data) {
          const data = result.data.collection === collection ? result.data.data : null;
          return { success: true, data };
        }
      } else {
        // Load all documents for the collection
        const allData = await window.dataSyncManager?.getAllAppData(appId);
        if (allData?.success) {
          const filtered = Object.entries(allData.data)
            .filter(([key, value]) => value.collection === collection)
            .map(([key, value]) => ({ id: key, ...value.data }));
          
          return { success: true, data: filtered };
        }
      }

      return { success: true, data: null };
    } catch (error) {
      console.error('Load data error:', error);
      return { success: false, error: error.message };
    }
  }

  async deleteData(collection, id, options = {}) {
    await this.requireAuth();
    
    const appId = options.app || 'main';
    
    try {
      await window.dataSyncManager?.delete(appId, id);
      
      this.emit('data:deleted', { collection, id, appId });
      this.trackEvent('data_deleted', { collection, app_id: appId });
      
      return { success: true };
    } catch (error) {
      console.error('Delete data error:', error);
      return { success: false, error: error.message };
    }
  }

  // ===============================================
  // File Storage Service
  // ===============================================

  async uploadFile(file, options = {}) {
    await this.requireAuth();
    
    const user = this.getCurrentUser();
    const category = options.category || 'general';
    const appId = options.app || 'main';
    
    // Generate unique filename
    const timestamp = Date.now();
    const filename = `${timestamp}_${file.name}`;
    const path = `${category}/${user.uid}/${appId}/${filename}`;
    
    try {
      const storageRef = ref(storage, path);
      
      // Set metadata
      const metadata = {
        contentType: file.type,
        customMetadata: {
          uploadedBy: user.uid,
          appId: appId,
          originalName: file.name,
          category: category,
          ...options.metadata
        }
      };

      // Track upload progress
      const uploadId = this.generateId();
      this.uploadProgress.set(uploadId, { progress: 0, status: 'uploading' });

      const uploadTask = uploadBytes(storageRef, file, metadata);
      
      // Update progress
      this.uploadProgress.set(uploadId, { progress: 50, status: 'processing' });
      
      const snapshot = await uploadTask;
      const downloadURL = await getDownloadURL(snapshot.ref);
      
      this.uploadProgress.set(uploadId, { progress: 100, status: 'completed' });
      
      const fileData = {
        id: uploadId,
        name: file.name,
        url: downloadURL,
        path: path,
        size: file.size,
        type: file.type,
        category: category,
        appId: appId,
        uploadedAt: new Date().toISOString(),
        uploadedBy: user.uid
      };

      // Save file record to Firestore
      await this.saveData('files', fileData, { app: appId, id: uploadId });

      this.emit('file:uploaded', { file: fileData });
      this.trackEvent('file_uploaded', { 
        category, 
        app_id: appId, 
        file_size: file.size,
        file_type: file.type 
      });
      
      return { success: true, file: fileData };
    } catch (error) {
      console.error('File upload error:', error);
      this.uploadProgress.set(uploadId, { progress: 0, status: 'error', error: error.message });
      return { success: false, error: error.message };
    }
  }

  async deleteFile(fileId, options = {}) {
    await this.requireAuth();
    
    try {
      // Get file data first
      const fileResult = await this.loadData('files', { id: fileId, app: options.app });
      
      if (fileResult.success && fileResult.data) {
        const fileData = fileResult.data;
        
        // Delete from storage
        const storageRef = ref(storage, fileData.path);
        await deleteObject(storageRef);
        
        // Delete from Firestore
        await this.deleteData('files', fileId, options);
        
        this.emit('file:deleted', { fileId });
        this.trackEvent('file_deleted', { app_id: options.app });
        
        return { success: true };
      } else {
        throw new Error('File not found');
      }
    } catch (error) {
      console.error('File delete error:', error);
      return { success: false, error: error.message };
    }
  }

  getUploadProgress(uploadId) {
    return this.uploadProgress.get(uploadId) || { progress: 0, status: 'unknown' };
  }

  // ===============================================
  // Preferences Service
  // ===============================================

  async savePreferences(appId, preferences) {
    await this.requireAuth();
    
    return this.saveData('preferences', preferences, {
      app: appId,
      id: `user_preferences`,
      metadata: { type: 'preferences' }
    });
  }

  async loadPreferences(appId) {
    await this.requireAuth();
    
    const result = await this.loadData('preferences', {
      app: appId,
      id: `user_preferences`
    });
    
    return result.success ? result.data || {} : {};
  }

  // ===============================================
  // Analytics Service
  // ===============================================

  trackEvent(event, properties = {}) {
    try {
      if (analytics) {
        logEvent(analytics, event, {
          ...properties,
          timestamp: new Date().toISOString(),
          user_id: this.getCurrentUser()?.uid,
          session_id: this.getSessionId(),
          url: window.location.href
        });
      }

      this.emit('analytics:tracked', { event, properties });
    } catch (error) {
      console.warn('Analytics tracking error:', error);
    }
  }

  trackPageView(page, properties = {}) {
    this.trackEvent('page_view', {
      page_title: page,
      page_location: window.location.href,
      ...properties
    });
  }

  trackAppUsage(appId, action, properties = {}) {
    this.trackEvent('app_usage', {
      app_id: appId,
      action: action,
      ...properties
    });
  }

  // ===============================================
  // Cloud Functions Service
  // ===============================================

  async callFunction(functionName, data = {}) {
    try {
      const callable = httpsCallable(functions, functionName);
      const result = await callable(data);
      return { success: true, data: result.data };
    } catch (error) {
      console.error(`Function ${functionName} error:`, error);
      return { success: false, error: error.message };
    }
  }

  // Common function calls
  async updateUserProfile(profileData) {
    return this.callFunction('updateUserProfile', profileData);
  }

  async upgradeUserPlan(plan) {
    return this.callFunction('upgradeUserPlan', { plan });
  }

  async generateAIContent(prompt, type = 'text') {
    return this.callFunction('generateAIContent', { prompt, type });
  }

  // ===============================================
  // Real-time Subscriptions
  // ===============================================

  subscribeToAppData(appId, callback) {
    if (!window.dataSyncManager) {
      console.error('Data sync manager not available');
      return () => {};
    }

    return window.dataSyncManager.subscribeToAppData(appId, callback);
  }

  subscribeToUserData(callback) {
    const user = this.getCurrentUser();
    if (!user) {
      console.error('User not authenticated');
      return () => {};
    }

    // Subscribe to user profile changes
    const userDocRef = doc(db, 'users', user.uid);
    const unsubscribe = onSnapshot(userDocRef, (doc) => {
      if (doc.exists()) {
        callback({
          type: 'user_profile_changed',
          data: doc.data()
        });
      }
    });

    return unsubscribe;
  }

  // ===============================================
  // Utility Methods
  // ===============================================

  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }

  getSessionId() {
    if (!this.sessionId) {
      this.sessionId = sessionStorage.getItem('firebase_session_id');
      if (!this.sessionId) {
        this.sessionId = `session_${this.generateId()}`;
        sessionStorage.setItem('firebase_session_id', this.sessionId);
      }
    }
    return this.sessionId;
  }

  async exportUserData() {
    await this.requireAuth();
    
    return window.dataSyncManager?.exportUserData();
  }

  async importUserData(data, options = {}) {
    await this.requireAuth();
    
    try {
      const results = {};
      
      for (const [appId, appData] of Object.entries(data)) {
        results[appId] = {};
        
        for (const [dataKey, dataValue] of Object.entries(appData)) {
          const result = await window.dataSyncManager?.set(appId, dataKey, dataValue);
          results[appId][dataKey] = result;
        }
      }

      return { success: true, results };
    } catch (error) {
      console.error('Import error:', error);
      return { success: false, error: error.message };
    }
  }

  // ===============================================
  // Event System
  // ===============================================

  on(event, callback) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event).push(callback);

    return () => {
      const listeners = this.eventListeners.get(event);
      const index = listeners.indexOf(callback);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    };
  }

  off(event, callback) {
    if (this.eventListeners.has(event)) {
      const listeners = this.eventListeners.get(event);
      const index = listeners.indexOf(callback);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
  }

  emit(event, data) {
    if (this.eventListeners.has(event)) {
      this.eventListeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error(`Error in event listener for ${event}:`, error);
        }
      });
    }
  }

  setupEventHandlers() {
    // Listen for auth state changes
    if (window.authManager) {
      window.authManager.subscribe((authEvent) => {
        this.emit('auth:state_changed', authEvent);
      });
    }

    // Track page visibility for analytics
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.trackEvent('page_hidden');
      } else {
        this.trackEvent('page_visible');
      }
    });

    // Track session duration
    const sessionStartTime = Date.now();
    window.addEventListener('beforeunload', () => {
      const sessionDuration = Date.now() - sessionStartTime;
      this.trackEvent('session_end', { duration: sessionDuration });
    });
  }

  // ===============================================
  // Service Status
  // ===============================================

  getServiceStatus() {
    return {
      auth: {
        isReady: window.authManager?.authReady || false,
        isSignedIn: this.isSignedIn(),
        user: this.getCurrentUser()
      },
      database: {
        isOnline: window.dataSyncManager?.isOnline || false,
        connectionState: window.dataSyncManager?.getConnectionState() || {}
      },
      storage: {
        isAvailable: !!storage
      },
      analytics: {
        isEnabled: !!analytics
      }
    };
  }
}

// Create global instance
const firebaseSharedServices = new FirebaseSharedServices();
window.sharedServices = firebaseSharedServices;

// Export for module usage
export default firebaseSharedServices;

// Expose simplified API for mini-apps
window.WebKemetAPI = {
  // Auth methods
  signIn: (credentials) => firebaseSharedServices.signIn(credentials),
  signUp: (userData) => firebaseSharedServices.signUp(userData),
  signInWithGoogle: () => firebaseSharedServices.signInWithGoogle(),
  signInWithGitHub: () => firebaseSharedServices.signInWithGitHub(),
  signOut: () => firebaseSharedServices.signOut(),
  isSignedIn: () => firebaseSharedServices.isSignedIn(),
  getCurrentUser: () => firebaseSharedServices.getCurrentUser(),
  requireAuth: () => firebaseSharedServices.requireAuth(),

  // Data methods
  saveData: (collection, data, options) => firebaseSharedServices.saveData(collection, data, options),
  loadData: (collection, options) => firebaseSharedServices.loadData(collection, options),
  deleteData: (collection, id, options) => firebaseSharedServices.deleteData(collection, id, options),

  // File methods
  uploadFile: (file, options) => firebaseSharedServices.uploadFile(file, options),
  deleteFile: (fileId, options) => firebaseSharedServices.deleteFile(fileId, options),
  getUploadProgress: (uploadId) => firebaseSharedServices.getUploadProgress(uploadId),

  // Preferences methods
  savePreferences: (appId, preferences) => firebaseSharedServices.savePreferences(appId, preferences),
  loadPreferences: (appId) => firebaseSharedServices.loadPreferences(appId),

  // Analytics methods
  trackEvent: (event, properties) => firebaseSharedServices.trackEvent(event, properties),
  trackPageView: (page, properties) => firebaseSharedServices.trackPageView(page, properties),
  trackAppUsage: (appId, action, properties) => firebaseSharedServices.trackAppUsage(appId, action, properties),

  // Subscription methods
  subscribeToAppData: (appId, callback) => firebaseSharedServices.subscribeToAppData(appId, callback),
  subscribeToUserData: (callback) => firebaseSharedServices.subscribeToUserData(callback),

  // Event methods
  on: (event, callback) => firebaseSharedServices.on(event, callback),
  off: (event, callback) => firebaseSharedServices.off(event, callback),

  // Utility methods
  generateId: () => firebaseSharedServices.generateId(),
  exportUserData: () => firebaseSharedServices.exportUserData(),
  importUserData: (data, options) => firebaseSharedServices.importUserData(data, options),
  getServiceStatus: () => firebaseSharedServices.getServiceStatus(),

  // Cloud Functions
  callFunction: (name, data) => firebaseSharedServices.callFunction(name, data),
  updateUserProfile: (data) => firebaseSharedServices.updateUserProfile(data),
  upgradeUserPlan: (plan) => firebaseSharedServices.upgradeUserPlan(plan),
  generateAIContent: (prompt, type) => firebaseSharedServices.generateAIContent(prompt, type)
};

// Legacy compatibility
if (typeof module !== 'undefined' && module.exports) {
  module.exports = firebaseSharedServices;
}