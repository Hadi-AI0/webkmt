/**
 * Firebase Data Synchronization Manager
 * Handles real-time data sharing and syncing across all mini-apps using Firestore
 */

import { 
  db, 
  analytics 
} from '../firebase-config.js';

import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  collection,
  query,
  where,
  orderBy,
  limit,
  onSnapshot,
  serverTimestamp,
  enableNetwork,
  disableNetwork,
  writeBatch
} from 'firebase/firestore';

import { logEvent } from 'firebase/analytics';

class FirebaseDataSyncManager {
  constructor() {
    this.isOnline = navigator.onLine;
    this.subscribers = new Map();
    this.activeListeners = new Map();
    this.offlineQueue = [];
    this.conflictResolvers = new Map();
    
    this.init();
  }

  init() {
    this.setupEventListeners();
    this.startHeartbeat();
  }

  setupEventListeners() {
    // Online/offline detection
    window.addEventListener('online', () => {
      this.isOnline = true;
      this.goOnline();
      this.processOfflineQueue();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
      this.goOffline();
    });

    // Listen for auth changes
    if (window.authManager && typeof window.authManager.subscribe === 'function') {
      window.authManager.subscribe((authEvent) => {
        if (authEvent.event === 'login') {
          this.setupUserDataListeners();
        } else if (authEvent.event === 'logout') {
          this.clearUserData();
        }
      });
    }

    // Cleanup before page unload
    window.addEventListener('beforeunload', () => {
      this.cleanup();
    });
  }

  // ===============================================
  // Data Management
  // ===============================================

  async get(appId, dataKey, options = {}) {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    try {
      const docPath = this.getDocumentPath(userId, appId, dataKey);
      const docRef = doc(db, ...docPath);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data();
        this.notifySubscribers(appId, dataKey, data.data);
        return { success: true, data: data.data, version: data.version };
      } else {
        return { success: true, data: null, version: 0 };
      }
    } catch (error) {
      console.error('Failed to get data:', error);
      return { success: false, error: error.message };
    }
  }

  async set(appId, dataKey, data, options = {}) {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    const operation = {
      type: 'set',
      appId,
      dataKey,
      data,
      options,
      timestamp: Date.now(),
      userId
    };

    if (!this.isOnline) {
      this.offlineQueue.push(operation);
      this.saveOfflineQueue();
      return { success: true, queued: true };
    }

    try {
      const result = await this.executeSetOperation(operation);
      this.trackDataOperation('data_set', appId, dataKey);
      return result;
    } catch (error) {
      // Queue for retry if network error
      if (this.isNetworkError(error)) {
        this.offlineQueue.push(operation);
        this.saveOfflineQueue();
      }
      throw error;
    }
  }

  async executeSetOperation(operation) {
    const { appId, dataKey, data, userId } = operation;
    const docPath = this.getDocumentPath(userId, appId, dataKey);
    const docRef = doc(db, ...docPath);

    const docData = {
      appId,
      dataKey,
      data,
      version: 1,
      lastSync: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    // Check for existing document to handle versioning
    const existingDoc = await getDoc(docRef);
    if (existingDoc.exists()) {
      docData.version = (existingDoc.data().version || 0) + 1;
    } else {
      docData.createdAt = serverTimestamp();
    }

    await setDoc(docRef, docData, { merge: true });
    this.notifySubscribers(appId, dataKey, data);

    return { success: true, version: docData.version };
  }

  async delete(appId, dataKey, options = {}) {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    const operation = {
      type: 'delete',
      appId,
      dataKey,
      options,
      timestamp: Date.now(),
      userId
    };

    if (!this.isOnline) {
      this.offlineQueue.push(operation);
      this.saveOfflineQueue();
      return { success: true, queued: true };
    }

    try {
      const docPath = this.getDocumentPath(userId, appId, dataKey);
      const docRef = doc(db, ...docPath);
      await deleteDoc(docRef);
      
      this.notifySubscribers(appId, dataKey, null);
      this.trackDataOperation('data_delete', appId, dataKey);
      
      return { success: true };
    } catch (error) {
      if (this.isNetworkError(error)) {
        this.offlineQueue.push(operation);
        this.saveOfflineQueue();
      }
      throw error;
    }
  }

  // ===============================================
  // Bulk Operations
  // ===============================================

  async setBulk(appId, dataMap) {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    try {
      const batch = writeBatch(db);
      const results = {};

      for (const [dataKey, data] of Object.entries(dataMap)) {
        const docPath = this.getDocumentPath(userId, appId, dataKey);
        const docRef = doc(db, ...docPath);
        
        const docData = {
          appId,
          dataKey,
          data,
          version: 1,
          lastSync: serverTimestamp(),
          updatedAt: serverTimestamp(),
          createdAt: serverTimestamp()
        };

        batch.set(docRef, docData, { merge: true });
        results[dataKey] = { success: true };
      }

      await batch.commit();
      
      // Notify subscribers
      for (const [dataKey, data] of Object.entries(dataMap)) {
        this.notifySubscribers(appId, dataKey, data);
      }

      this.trackDataOperation('data_bulk_set', appId, Object.keys(dataMap).length);
      return { success: true, results };
    } catch (error) {
      console.error('Bulk set error:', error);
      return { success: false, error: error.message };
    }
  }

  async getAllAppData(appId) {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    try {
      const collectionRef = collection(db, 'userData', userId, 'apps', appId, 'data');
      const q = query(collectionRef, orderBy('updatedAt', 'desc'));
      
      const querySnapshot = await getDocs(q);
      const data = {};
      
      querySnapshot.forEach((doc) => {
        const docData = doc.data();
        data[docData.dataKey] = docData.data;
      });

      return { success: true, data };
    } catch (error) {
      console.error('Get all app data error:', error);
      return { success: false, error: error.message };
    }
  }

  // ===============================================
  // Real-time Subscriptions
  // ===============================================

  subscribeToAppData(appId, callback) {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    const collectionRef = collection(db, 'userData', userId, 'apps', appId, 'data');
    const q = query(collectionRef, orderBy('updatedAt', 'desc'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const changes = [];
      const data = {};

      snapshot.forEach((doc) => {
        const docData = doc.data();
        data[docData.dataKey] = docData.data;
      });

      snapshot.docChanges().forEach((change) => {
        const docData = change.doc.data();
        changes.push({
          type: change.type,
          dataKey: docData.dataKey,
          data: docData.data,
          timestamp: docData.updatedAt
        });
      });

      callback({ type: 'app_data_changed', appId, data, changes });
    }, (error) => {
      console.error('Subscription error:', error);
      callback({ type: 'subscription_error', error: error.message });
    });

    // Store the unsubscribe function
    const subscriptionKey = `${appId}_app_data`;
    this.activeListeners.set(subscriptionKey, unsubscribe);

    return () => {
      unsubscribe();
      this.activeListeners.delete(subscriptionKey);
    };
  }

  subscribeToDataKey(appId, dataKey, callback) {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    const docPath = this.getDocumentPath(userId, appId, dataKey);
    const docRef = doc(db, ...docPath);

    const unsubscribe = onSnapshot(docRef, (doc) => {
      if (doc.exists()) {
        const data = doc.data();
        callback({
          type: 'data_changed',
          appId,
          dataKey,
          data: data.data,
          version: data.version,
          timestamp: data.updatedAt
        });
      } else {
        callback({
          type: 'data_deleted',
          appId,
          dataKey,
          data: null
        });
      }
    }, (error) => {
      console.error('Data key subscription error:', error);
      callback({ type: 'subscription_error', error: error.message });
    });

    const subscriptionKey = `${appId}_${dataKey}`;
    this.activeListeners.set(subscriptionKey, unsubscribe);

    return () => {
      unsubscribe();
      this.activeListeners.delete(subscriptionKey);
    };
  }

  // ===============================================
  // Offline Support
  // ===============================================

  async processOfflineQueue() {
    if (this.offlineQueue.length === 0) return;

    const queue = [...this.offlineQueue];
    this.offlineQueue = [];

    for (const operation of queue) {
      try {
        if (operation.type === 'set') {
          await this.executeSetOperation(operation);
        } else if (operation.type === 'delete') {
          const docPath = this.getDocumentPath(operation.userId, operation.appId, operation.dataKey);
          const docRef = doc(db, ...docPath);
          await deleteDoc(docRef);
        }
      } catch (error) {
        console.error('Offline queue operation failed:', error);
        // Re-queue if still network error
        if (this.isNetworkError(error)) {
          this.offlineQueue.push(operation);
        }
      }
    }

    this.saveOfflineQueue();
  }

  saveOfflineQueue() {
    try {
      localStorage.setItem('firebase_offline_queue', JSON.stringify(this.offlineQueue));
    } catch (error) {
      console.error('Failed to save offline queue:', error);
    }
  }

  loadOfflineQueue() {
    try {
      const queue = localStorage.getItem('firebase_offline_queue');
      if (queue) {
        this.offlineQueue = JSON.parse(queue);
      }
    } catch (error) {
      console.error('Failed to load offline queue:', error);
      this.offlineQueue = [];
    }
  }

  async goOnline() {
    try {
      await enableNetwork(db);
      console.log('🟢 Firestore online');
    } catch (error) {
      console.error('Error enabling network:', error);
    }
  }

  async goOffline() {
    try {
      await disableNetwork(db);
      console.log('🔴 Firestore offline');
    } catch (error) {
      console.error('Error disabling network:', error);
    }
  }

  // ===============================================
  // Helper Methods
  // ===============================================

  getDocumentPath(userId, appId, dataKey) {
    return ['userData', userId, 'apps', appId, 'data', dataKey];
  }

  getCurrentUserId() {
    return window.authManager?.getCurrentUser()?.uid;
  }

  isNetworkError(error) {
    return error.code === 'unavailable' || 
           error.code === 'deadline-exceeded' ||
           error.message.includes('network');
  }

  setupUserDataListeners() {
    // Set up any global user data listeners here
    console.log('Setting up user data listeners');
  }

  clearUserData() {
    // Clear all subscriptions
    this.activeListeners.forEach(unsubscribe => unsubscribe());
    this.activeListeners.clear();
    
    // Clear offline queue
    this.offlineQueue = [];
    this.saveOfflineQueue();
    
    console.log('User data cleared');
  }

  // ===============================================
  // Event System
  // ===============================================

  subscribe(appId, dataKey, callback) {
    const subscriptionKey = `${appId}:${dataKey}`;
    
    if (!this.subscribers.has(subscriptionKey)) {
      this.subscribers.set(subscriptionKey, new Set());
    }
    
    this.subscribers.get(subscriptionKey).add(callback);
    
    return () => {
      const subs = this.subscribers.get(subscriptionKey);
      if (subs) {
        subs.delete(callback);
        if (subs.size === 0) {
          this.subscribers.delete(subscriptionKey);
        }
      }
    };
  }

  notifySubscribers(appId, dataKey, data) {
    const subscriptionKey = `${appId}:${dataKey}`;
    const subscribers = this.subscribers.get(subscriptionKey);
    
    if (subscribers) {
      subscribers.forEach(callback => {
        try {
          callback({ appId, dataKey, data });
        } catch (error) {
          console.error('Subscriber callback error:', error);
        }
      });
    }
  }

  // ===============================================
  // Analytics
  // ===============================================

  trackDataOperation(event, appId, detail) {
    try {
      if (analytics) {
        logEvent(analytics, event, {
          app_id: appId,
          detail: detail,
          user_id: this.getCurrentUserId(),
          timestamp: new Date().toISOString()
        });
      }
    } catch (error) {
      console.warn('Analytics tracking error:', error);
    }
  }

  // ===============================================
  // Utility Methods
  // ===============================================

  async exportUserData() {
    const userId = this.getCurrentUserId();
    if (!userId) {
      throw new Error('User not authenticated');
    }

    try {
      const userDataRef = collection(db, 'userData', userId, 'apps');
      const snapshot = await getDocs(userDataRef);
      
      const exportData = {};
      
      for (const appDoc of snapshot.docs) {
        const appId = appDoc.id;
        const dataRef = collection(db, 'userData', userId, 'apps', appId, 'data');
        const dataSnapshot = await getDocs(dataRef);
        
        exportData[appId] = {};
        dataSnapshot.forEach(doc => {
          const data = doc.data();
          exportData[appId][data.dataKey] = data.data;
        });
      }

      return { success: true, data: exportData };
    } catch (error) {
      console.error('Export error:', error);
      return { success: false, error: error.message };
    }
  }

  getConnectionState() {
    return {
      isOnline: this.isOnline,
      queueSize: this.offlineQueue.length,
      activeListeners: this.activeListeners.size,
      subscriberCount: Array.from(this.subscribers.values())
        .reduce((total, subs) => total + subs.size, 0)
    };
  }

  startHeartbeat() {
    // Check connection and process queue every 30 seconds
    setInterval(() => {
      if (this.isOnline && this.offlineQueue.length > 0) {
        this.processOfflineQueue();
      }
    }, 30000);
  }

  cleanup() {
    // Clean up all listeners
    this.activeListeners.forEach(unsubscribe => unsubscribe());
    this.activeListeners.clear();
    this.subscribers.clear();
  }
}

// Global instance
const firebaseDataSyncManager = new FirebaseDataSyncManager();
window.dataSyncManager = firebaseDataSyncManager;

// Export for module usage
export default firebaseDataSyncManager;

// Legacy compatibility
if (typeof module !== 'undefined' && module.exports) {
  module.exports = firebaseDataSyncManager;
}