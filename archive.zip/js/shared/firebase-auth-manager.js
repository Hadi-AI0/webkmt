/**
 * Firebase Authentication Manager
 * Handles authentication using Firebase Auth across all mini-apps
 */

import { 
  auth, 
  db, 
  analytics 
} from '../firebase-config.js';

import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithCustomToken,
  signInWithPopup,
  GoogleAuthProvider,
  GithubAuthProvider,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail,
  updatePassword,
  signInAnonymously
} from 'firebase/auth';

import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp,
  enableNetwork,
  disableNetwork
} from 'firebase/firestore';

import { logEvent } from 'firebase/analytics';

class FirebaseAuthManager {
  constructor() {
    this.user = null;
    this.isAuthenticated = false;
    this.subscribers = new Set();
    this.authReady = false;
    this.userProfile = null;
    
    this.init();
  }

  async init() {
    // Listen for auth state changes
    onAuthStateChanged(auth, async (user) => {
      this.user = user;
      this.isAuthenticated = !!user;
      
      if (user) {
        await this.loadUserProfile();
        this.trackEvent('user_sign_in', { method: 'session_restored' });
      } else {
        this.userProfile = null;
      }
      
      this.authReady = true;
      this.notifySubscribers(user ? 'login' : 'logout', user);
    });
  }

  // ===============================================
  // Authentication Methods
  // ===============================================

  async signInWithEmail(email, password, rememberMe = true) {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      await this.createOrUpdateUserProfile(user);
      this.trackEvent('user_sign_in', { method: 'email' });

      return { success: true, user: this.getUserData() };
    } catch (error) {
      console.error('Email sign-in error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async signUpWithEmail(email, password, displayName) {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Update the user's display name
      await updateProfile(user, { displayName });

      // Create user profile in Firestore
      await this.createOrUpdateUserProfile(user, { displayName });
      this.trackEvent('user_sign_up', { method: 'email' });

      return { success: true, user: this.getUserData() };
    } catch (error) {
      console.error('Email sign-up error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async signInWithGoogle() {
    try {
      const provider = new GoogleAuthProvider();
      provider.addScope('profile');
      provider.addScope('email');
      
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      await this.createOrUpdateUserProfile(user);
      this.trackEvent('user_sign_in', { method: 'google' });
      
      return { success: true, user: this.getUserData() };
    } catch (error) {
      console.error('Google sign-in error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async signInWithGitHub() {
    try {
      const provider = new GithubAuthProvider();
      provider.addScope('user:email');
      
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      await this.createOrUpdateUserProfile(user);
      this.trackEvent('user_sign_in', { method: 'github' });
      
      return { success: true, user: this.getUserData() };
    } catch (error) {
      console.error('GitHub sign-in error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async signInAnonymously() {
    try {
      const userCredential = await signInAnonymously(auth);
      const user = userCredential.user;
      
      await this.createOrUpdateUserProfile(user, { 
        isAnonymous: true,
        displayName: 'Guest User'
      });
      
      this.trackEvent('user_sign_in', { method: 'anonymous' });
      
      return { success: true, user: this.getUserData() };
    } catch (error) {
      console.error('Anonymous sign-in error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async signOut() {
    try {
      this.trackEvent('user_sign_out');
      await signOut(auth);
      this.userProfile = null;
      return { success: true };
    } catch (error) {
      console.error('Sign-out error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  // ===============================================
  // User Profile Management
  // ===============================================

  async createOrUpdateUserProfile(user, additionalData = {}) {
    try {
      const userRef = doc(db, 'users', user.uid);
      const userSnap = await getDoc(userRef);

      // Determine user role - info@webkmt.com gets admin role
      const isAdmin = user.email && user.email.toLowerCase() === 'info@webkmt.com';
      const userRole = isAdmin ? 'admin' : 'user';

      const userData = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName || additionalData.displayName || 'User',
        photoURL: user.photoURL,
        emailVerified: user.emailVerified,
        isAnonymous: user.isAnonymous || additionalData.isAnonymous || false,
        lastSignIn: serverTimestamp(),
        updatedAt: serverTimestamp(),
        ...additionalData
      };

      if (userSnap.exists()) {
        // Update existing user, preserve role unless it's admin
        const existingData = userSnap.data();
        await updateDoc(userRef, {
          ...userData,
          role: existingData.role || userRole // Don't overwrite existing role unless new user is admin
        });
      } else {
        // Create new user with defaults
        await setDoc(userRef, {
          ...userData,
          role: userRole,
          plan: userRole === 'admin' ? 'premium' : 'free',
          preferences: {
            theme: 'light',
            language: 'en',
            notifications: true
          },
          createdAt: serverTimestamp()
        });

        // For new users, trigger server-side role assignment if needed
        if (isAdmin) {
          try {
            // Call server endpoint to set custom claims
            const idToken = await user.getIdToken();
            await fetch('/api/auth/set-claims', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${idToken}`
              },
              body: JSON.stringify({ uid: user.uid, role: userRole })
            });
          } catch (error) {
            console.warn('Failed to set server-side claims:', error);
          }
        }
      }

      // Reload user profile
      await this.loadUserProfile();

    } catch (error) {
      console.error('Error creating/updating user profile:', error);
    }
  }

  async loadUserProfile() {
    if (!this.user) {
      this.userProfile = null;
      return;
    }

    try {
      const userRef = doc(db, 'users', this.user.uid);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        this.userProfile = userSnap.data();
      } else {
        // Create profile if it doesn't exist
        await this.createOrUpdateUserProfile(this.user);
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
      this.userProfile = null;
    }
  }

  async updateUserProfile(updates) {
    if (!this.user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      const userRef = doc(db, 'users', this.user.uid);
      await updateDoc(userRef, {
        ...updates,
        updatedAt: serverTimestamp()
      });

      // Update Firebase Auth profile if needed
      if (updates.displayName || updates.photoURL) {
        await updateProfile(this.user, {
          displayName: updates.displayName,
          photoURL: updates.photoURL
        });
      }

      await this.loadUserProfile();
      this.notifySubscribers('profile_updated', this.userProfile);
      
      return { success: true, user: this.getUserData() };
    } catch (error) {
      console.error('Profile update error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  // ===============================================
  // Password Management
  // ===============================================

  async resetPassword(email) {
    try {
      await sendPasswordResetEmail(auth, email);
      return { success: true, message: 'Password reset email sent' };
    } catch (error) {
      console.error('Password reset error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  async changePassword(newPassword) {
    if (!this.user) {
      return { success: false, error: 'User not authenticated' };
    }

    try {
      await updatePassword(this.user, newPassword);
      return { success: true, message: 'Password updated successfully' };
    } catch (error) {
      console.error('Password change error:', error);
      return { success: false, error: this.getErrorMessage(error) };
    }
  }

  // ===============================================
  // Utility Methods
  // ===============================================

  getUserData() {
    if (!this.user) return null;

    // Return user data even if profile hasn't loaded yet
    // Profile data will be merged in when available
    const userData = {
      uid: this.user.uid,
      email: this.user.email,
      displayName: this.user.displayName,
      photoURL: this.user.photoURL,
      emailVerified: this.user.emailVerified,
      isAnonymous: this.user.isAnonymous
    };

    // Merge profile data if available
    if (this.userProfile) {
      Object.assign(userData, this.userProfile);
    }

    return userData;
  }

  getErrorMessage(error) {
    const errorMessages = {
      'auth/user-not-found': 'No account found with this email address',
      'auth/wrong-password': 'Incorrect password',
      'auth/email-already-in-use': 'An account with this email already exists',
      'auth/weak-password': 'Password should be at least 6 characters',
      'auth/invalid-email': 'Invalid email address',
      'auth/too-many-requests': 'Too many failed attempts. Please try again later',
      'auth/user-disabled': 'This account has been disabled',
      'auth/operation-not-allowed': 'This sign-in method is not enabled',
      'auth/popup-closed-by-user': 'Sign-in popup was closed',
      'auth/cancelled-popup-request': 'Sign-in cancelled',
      'auth/network-request-failed': 'Network error. Please check your connection'
    };

    return errorMessages[error.code] || error.message || 'An unexpected error occurred';
  }

  // ===============================================
  // Analytics & Tracking
  // ===============================================

  trackEvent(event, properties = {}) {
    try {
      if (analytics) {
        logEvent(analytics, event, {
          ...properties,
          user_id: this.user?.uid,
          timestamp: new Date().toISOString()
        });
      }
    } catch (error) {
      console.warn('Analytics error:', error);
    }
  }

  // ===============================================
  // Event System
  // ===============================================

  subscribe(callback) {
    this.subscribers.add(callback);
    
    // If auth is ready, immediately call with current state
    if (this.authReady) {
      callback({ 
        event: this.isAuthenticated ? 'login' : 'logout',
        data: this.getUserData(),
        user: this.getUserData(),
        isAuthenticated: this.isAuthenticated 
      });
    }
    
    return () => this.subscribers.delete(callback);
  }

  notifySubscribers(event, data = null) {
    this.subscribers.forEach(callback => {
      try {
        callback({ 
          event, 
          data, 
          user: this.getUserData(), 
          isAuthenticated: this.isAuthenticated 
        });
      } catch (error) {
        console.error('Subscriber callback error:', error);
      }
    });
  }

  // ===============================================
  // Public API
  // ===============================================

  getUser() {
    return this.getUserData();
  }

  isLoggedIn() {
    return this.isAuthenticated && !this.user?.isAnonymous;
  }

  isGuest() {
    return this.isAuthenticated && this.user?.isAnonymous;
  }

  getCurrentUser() {
    return this.user;
  }

  getUserProfile() {
    return this.userProfile;
  }

  waitForAuth() {
    return new Promise((resolve) => {
      if (this.authReady) {
        resolve(this.isAuthenticated);
      } else {
        const unsubscribe = this.subscribe(() => {
          unsubscribe();
          resolve(this.isAuthenticated);
        });
      }
    });
  }

  // Network status methods for offline support
  async goOnline() {
    try {
      await enableNetwork(db);
      return true;
    } catch (error) {
      console.error('Error going online:', error);
      return false;
    }
  }

  async goOffline() {
    try {
      await disableNetwork(db);
      return true;
    } catch (error) {
      console.error('Error going offline:', error);
      return false;
    }
  }
}

// Global instance
console.log('🔥 Creating Firebase Auth Manager...');
const firebaseAuthManager = new FirebaseAuthManager();
window.authManager = firebaseAuthManager;
console.log('✅ Firebase Auth Manager available globally:', !!window.authManager);

// Export for module usage
export default firebaseAuthManager;

// Legacy compatibility
if (typeof module !== 'undefined' && module.exports) {
  module.exports = firebaseAuthManager;
}