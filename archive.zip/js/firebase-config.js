/**
 * Firebase Configuration and Initialization
 * Provides Firebase services for authentication, database, and storage
 */

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore, enableNetwork, connectFirestoreEmulator } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAnalytics } from "firebase/analytics";
import { getFunctions } from "firebase/functions";
import { initializeAppCheck, ReCaptchaV3Provider } from "firebase/app-check";

// Firebase configuration - loaded from window.FIREBASE_CONFIG
const firebaseConfig = window.FIREBASE_CONFIG || {
  apiKey: "AIzaSyDHrBrZ82HKPzBiNe1ZqsSth5cJxROJxzk",
  authDomain: "webkmt-40b44.firebaseapp.com",
  projectId: "webkmt-40b44",
  storageBucket: "webkmt-40b44.firebasestorage.app",
  messagingSenderId: "865748583121",
  appId: "1:865748583121:web:4f3f6352383946de46fbf0",
  measurementId: "G-GR8Q4Y853X"
};

// Initialize Firebase
console.log('🔥 Initializing Firebase app with config:', {
  projectId: firebaseConfig.projectId,
  authDomain: firebaseConfig.authDomain
});

const app = initializeApp(firebaseConfig);
console.log('✅ Firebase app initialized');

// App Check - TEMPORARILY DISABLED for development
// The ReCAPTCHA integration is causing errors
// Re-enable before production deployment by uncommenting the code below
console.log('⚠️ App Check is DISABLED - development mode');

/*
// Initialize App Check (REQUIRED by Firebase backend)
if (typeof window !== 'undefined') {
  try {
    // Check if running on localhost - use debug token if available
    const isLocalhost = window.location.hostname === 'localhost' ||
                       window.location.hostname === '127.0.0.1';

    if (isLocalhost) {
      console.log('🔧 Running on localhost - App Check with debug mode');
      // For localhost, we need a debug token from Firebase Console
      // Go to: Firebase Console → App Check → Add debug token
      // Set: self.FIREBASE_APPCHECK_DEBUG_TOKEN = true; in browser console

      // Enable debug mode for App Check
      if (!window.FIREBASE_APPCHECK_DEBUG_TOKEN) {
        console.warn('⚠️ Set debug token: Run in console: self.FIREBASE_APPCHECK_DEBUG_TOKEN = true');
      }
    }

    const appCheck = initializeAppCheck(app, {
      provider: new ReCaptchaV3Provider('6LfyK9YrAAAAAMXVu9RlZJYcCHXZ39JJaNQJeiaB'),
      isTokenAutoRefreshEnabled: true
    });
    console.log('🔒 App Check initialized with reCAPTCHA v3');
  } catch (error) {
    console.error('❌ App Check initialization failed:', error);
    console.error('This will cause auth to fail. Check reCAPTCHA key and App Check settings.');
  }
}
*/

// Initialize Firebase services with detailed error handling
let auth, db, storage, functions;

try {
    console.log('🔧 Initializing Firebase Auth...');
    auth = getAuth(app);
    console.log('✅ Firebase Auth initialized');

    console.log('🔧 Initializing Firestore...');
    db = getFirestore(app);
    console.log('✅ Firestore initialized');

    console.log('🔧 Initializing Storage...');
    storage = getStorage(app);
    console.log('✅ Storage initialized');

    console.log('🔧 Initializing Functions...');
    functions = getFunctions(app);
    console.log('✅ Functions initialized');

    console.log('🎉 All Firebase services initialized successfully');
} catch (error) {
    console.error('❌ Firebase service initialization failed:', error);
    console.error('Error details:', {
      code: error.code,
      message: error.message,
      stack: error.stack
    });
    throw error;
}

// Initialize Analytics for production
let analytics = null;
if (typeof window !== 'undefined') {
  try {
    analytics = getAnalytics(app);
    console.log('✅ Firebase Analytics initialized');
  } catch (error) {
    console.warn('Analytics initialization failed:', error);
  }
}

// Production Firebase - no emulators
console.log('🔥 Using production Firebase services');

// Enable Firestore network connection
if (typeof window !== 'undefined') {
  try {
    enableNetwork(db).then(() => {
      console.log('✅ Firestore network enabled');
    }).catch((error) => {
      console.warn('Firestore network setup failed:', error);
    });
  } catch (error) {
    console.warn('Firestore configuration error:', error);
  }
}

// Export Firebase services
export {
  app,
  auth,
  db,
  storage,
  functions,
  analytics,
  firebaseConfig
};

// Export helper functions - production only
export const isEmulator = false;
export const isProduction = true;

// Firebase app instance for legacy compatibility
// Centralized Firebase access through manager only
// Deprecated: Direct global access - use window.firebaseManager instead

// Firebase Manager Class for Optimized Loading
class FirebaseManager {
  constructor() {
    this.app = app;
    this.auth = auth;
    this.firestore = db;
    this.storage = storage;
    this.analytics = analytics;
    this.functions = functions;
    this.initialized = true;
    this.loadedServices = new Set(['core', 'auth', 'firestore', 'storage', 'functions']);
    
    if (analytics) {
      this.loadedServices.add('analytics');
    }
  }

  async init() {
    // Already initialized, return immediately
    return Promise.resolve();
  }

  async loadServicesOnDemand(services = []) {
    // All services are already loaded
    return Promise.resolve();
  }

  isDevelopment() {
    return false; // Production only
  }

  isInitialized() {
    return this.initialized;
  }

  getLoadedServices() {
    return Array.from(this.loadedServices);
  }

  async getAuthManager() {
    if (!window.authManager) {
      const { default: FirebaseAuthManager } = await import('./shared/firebase-auth-manager.js');
      // Auth manager is initialized globally
    }
    return window.authManager;
  }

  async getDataSyncManager() {
    if (!window.dataSyncManager) {
      const { default: FirebaseDataSyncManager } = await import('./shared/firebase-data-sync.js');
      // Data sync manager is initialized globally
    }
    return window.dataSyncManager;
  }

  async getSharedServices() {
    if (!window.sharedServices) {
      const { default: FirebaseSharedServices } = await import('./shared/firebase-shared-services.js');
      // Shared services are initialized globally
    }
    return window.sharedServices;
  }

  getPerformanceStats() {
    return {
      initialized: this.initialized,
      loadedServices: this.getLoadedServices(),
      isDevelopment: this.isDevelopment()
    };
  }
}

// Create global firebase manager instance
const firebaseManager = new FirebaseManager();
window.firebaseManager = firebaseManager;
window.firebase = { app: () => app };

// Export the manager
export { firebaseManager };

